<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DANH SÁCH SẢN PHẨM - Vũ Đức Khoa</title>
</head>
<body>
    <?php 
        include("ketnoi-vuduckhoa.php");
        $sql_vdk = "SELECT * FROM danhmuc_vdk WHERE 1=1 ";
        $result_vdk = $conn_vdk->query($sql_vdk);
     ?>
    <section>
        <h1>DANH SÁCH SẢN PHẨM - Vũ Đức Khoa</h1>
        <hr/>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>Stt</th>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    if($result_vdk->num_rows>0){
                        $stt=0;
                        while($row_vdk=$result_vdk->fetch_array()):
                            $stt++;
                ?>
                    <tr>
                        <td><?php echo $stt; ?></td>
                        <td><?php echo $row_vdk["MADM_VDK"]; ?></td>
                        <td><?php echo $row_vdk["TENDM_VDK"]; ?></td>
                        <td><?php echo $row_vdk["TRANGTHAI_VDK"]; ?></td>
                        <td>
                            <a href="danhmuc-edit-vdk.php?MADM_VDK=<?php echo $row_vdk["MADM_VDK"];?>">
                                Sửa
                            </a>
                            |
                            <a href="danhmuc-list-vdk.php?MADM_VDK=<?php echo $row_vdk["MADM_VDK"];?>"
                                onclick="if(confirm('Bạn có muốn xóa không')){return true;}else{return false;}">
                                Xóa
                            </a>
                        </td>
                    </tr>
                <?php 
                        endwhile;
                    }else{
                ?>
                    <tr>
                        <td colspan="9">Chưa có dữ liệu</td>
                    </tr>
                <?php
                    };
                ?>
            </tbody>
        </table>
    </section>

    <?php 
        if(isset($_GET["MADM_VDK"])){
            $MADM_VDK = $_GET["MADM_VDK"];
            $sql_delete_vdk = "DELETE FROM danhmuc_vdk WHERE MADM_VDK='$MADM_VDK'";
            if($conn_vdk->query($sql_delete_vdk)){
                header("Location: danhmuc-list-vdk.php");
            }else{
                echo "<script> alert('lỗi xóa'); </script>";
            }
        }
    ?>
</body>
</html>