<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DANH SÁCH SẢN PHẨM - Vũ Đức Khoa</title>
</head>
<body>
    <?php 
        include("ketnoi-vuduckhoa.php");
        $sql_vdk = "SELECT * FROM bang_vuduckhoa WHERE 1 =1 ";
        $result_vdk = $conn_vdk->query($sql_vdk);
    ?>
    <?php
        if(isset($_GET["id"])){
            $sql_vdk_delete = "DELETE FROM bang_vuduckhoa WHERE MA_2210900032='" . $_GET["id"] . "'";
            if($conn_vdk->query($sql_vdk_delete)){
                header("location:sanpham-list-vuduckhoa.php");
            }
        }
    ?>
    <header>
        <h1> Danh sách hiển thị sản phẩm -Vũ Đức Khoa-2210900032</h1>
    </header>
    <section>
        <a href="sanpham-add-vuduckhoa.php">thêm mới</a>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>Stt</th>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Sl</th>
                    <th>đơn giá</th>
                    <th>ảnh</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                        $stt_vdk=0;
                        while($row_vdk = $result_vdk->fetch_array()){
                            $stt_vdk ++;
                ?>
                    <tr>
                        <td><?php echo $stt_vdk; ?></td>
                        <td><?php echo $row_vdk["MA_2210900032"]; ?></td>
                        <td><?php echo $row_vdk["TEN_2210900032"]; ?></td>
                        <td><?php echo $row_vdk["SL_2210900032"]; ?></td>
                        <td><?php echo $row_vdk["DG_2210900032"]; ?></td>
                        <td><?php echo $row_vdk["ANH_2210900032"]; ?></td>
                        <td><?php echo 
                                $row_vdk["TRANGTHAI_2210900032"]==true?" yêu em":"ẩn";  ?></td>
                        <td>
                            <a href="sanpham-edit-vuduckhoa.php?id=<?php echo $row_vdk["MA_2210900032"]; ?>"> sửa</a> 
                            |
                            <a href="sanpham-list-vuduckhoa.php?id=<?php echo $row_vdk["MA_2210900032"]; ?>"> xóa</a>
                        </td>
                        
                    </tr>
                <?php 
                        }
                ?>
            </tbody>
        </table>
    </section>

</body>
</html>