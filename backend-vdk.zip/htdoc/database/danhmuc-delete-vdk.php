<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách danh mục</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-vuduckhoa.php");
        $sql_vdk = "SELECT * FROM danhmuc_vdk WHERE 1=1";
        $result_vdk = $conn_vdk->query($sql_vdk);
        //Duyệt và hiển thị kết quả -> tbody
    ?>
    <section class="container">
        <h1>Danh sách sản phẩm</h1>
        <hr/>
        <a href="danhmuc-create-vdk.php" class="btn">Thêm mới sản phẩm</a>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã danh mục</th>
                    <th>Tên</th>
                    <th>Trạng thái</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    if($result_vdk->num_rows>0){
                        $stt=0;
                        while($row_vdk = $result_vdk->fetch_array()):
                        $stt++;
                ?>
                <tr>
                    <td><?php echo $stt;?></td>
                    <td><?php echo $row_vdk["MADM_VDK"];?></td>
                    <td><?php echo $row_vdk["TENDM_VDK"];?></td>
                    <td><?php echo $row_vdk["TRANGTHAI_VDK"];?></td>
                    <td>
                        <a href="danhmuc-edit-vdk.php?MADM_VDK=<?php echo $row_vdk["MADM_VDK"];?>">Sửa</a>|
                        <a href="danhmuc-list-vdk.php?MADM_VDK=<?php echo $row_vdk["MADM_VDK"];?>">Xóa</a>
                    </td>
                </tr>
                <?php
                    endwhile;
                }
                ?>
            </tbody>
        </table>
        <a href="danhmuc-create-vdk.php" class="btn">Thêm mới sản phẩm</a>
    </section>
    <?php
        if(isset($_GET["MADM_VDK"])){
            $proid_vdk = $_GET["MADM_VDK"];
            $sql_delete_vdk = "DELETE FROM DANHMUC_VDK where MADM_ID ='$MADM_vdk'";
            if($conn_vdk->query($sql_delete_vdk)){
                header("Location:danhmuc-list-vdk.php");
            }else{
                echo "<script> alert('lỗi xóa'; </script>";
            }
        }
    ?>
</body>
</html>