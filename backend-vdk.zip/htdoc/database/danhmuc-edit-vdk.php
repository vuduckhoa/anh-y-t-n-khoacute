<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bạn khoa làm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
    <?php
        include("ketnoi-vuduckhoa.php");
        if(isset($_GET["MADM_VDK"])){
            $MADM_VDK= $_GET["MADM_VDK"];
            $sql_edit_vdk= "SELECT * FROM danhmuc_vdk WHERE MADM_VDK='$MADM_VDK'";
            $result_edit_vdk = $conn_vdk->query($sql_edit_vdk);
            $row_edit_vdk = $result_edit_vdk->fetch_array();
        }else{
            header("Location: danhmuc-list-vdk.php");
        }
        $sql_pb_vdk = "SELECT * FROM danhmuc_vdk WHERE 1=1";
        $res_pb_vdk = $conn_vdk->query($sql_pb_vdk);
        $error_message_vdk ="";
        if(isset($_POST["btnSubmit_vdk"])){
            $MADM_VDK = $_POST["MADM_VDK"];
            $TENDM_VDK = $_POST["TENDM_VDK"];
            $TRANGTHAI_VDK = $_POST["TRANGTHAI_VDK"];
            $sql_update_vdk= "UPDATE danhmuc_vdk SET";
            $sql_update_vdk.="MADM_VDK='$MADM_VDK',";
            $sql_update_vdk.="TENDM_VDK='$TENDM_VDK',";
            $sql_update_vdk.="TRANGTHAI_VDK='$TRANGTHAI_VDK',";
            if($conn_vdk->query($sql_update_vdk)){
                header("Location: danhmuc-list-vdk.php"); 
            }else{
                $error_message_vdk="Lỗi sửa dữ liệu". mysqli_error($conn_vdk);
            }
        }
    ?>
    <section class="container">
        <h1>bạn khoa đang thêm mới thông tin sản phẩm</h1>
        <form name="frm_vdk" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                            <select name="MADM_VDK" id="MADM_VDK">
                                <?php
                                    while($row = $res_pb_vdk->fetch_array()):        
                                ?>
                                <option value="<?php echo $row["MADM_VDK"]?>"
                                <?php
                                    if($row["MADM_VDK"]==$row_edit_vdk["MADM_VDK"]){
                                        echo "selected";
                                    }
                                ?>
                                >
                                </option>
                                <?php
                                    endwhile;
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TENDM_VDK" id="TENDM_VDK"
                                value="<?php echo  $row_edit_vdk["TENDM_VDK"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_VDK" >
                                <option value="1" <?php if($row_edit_vdk["TRANGTHAI_VDK"]==1){echo "selected";}?>>Hoạt động</option>
                                <option value="0" <?php if($row_edit_vdk["TRANGTHAI_VDK"]==0){echo "selected";}?>>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" value="Thêm" name="btnSubmit_vdk">
                            <input type="reset" value="Làm lại" name="btnReset_vdk">
                        </td>
                    </tr>
                </tbody>
            </table>    
            <div>
                <?php echo $error_message_vdk;?>
            </div>
        </form>
        <a href="danhmuc-list-vdk.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>