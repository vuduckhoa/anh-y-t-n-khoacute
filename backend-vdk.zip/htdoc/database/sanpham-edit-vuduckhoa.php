<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sửa Vũ Đức Khoa 2210900032</title>
</head>
<body>
    <?php
    $error_vdk="";
    include("ketnoi-vuduckhoa.php");
    if(isset($_POST["btn_vdk"])){
        $MA_2210900032 = $_POST["MA_2210900032"];
        $TEN_2210900032 = $_POST["TEN_2210900032"];
        $SL_2210900032 = $_POST["SL_2210900032"];
        $DG_2210900032 = $_POST["DG_2210900032"];
        $ANH_2210900032 = $_POST["ANH_2210900032"];
        $TRANGTHAI_2210900032 = $_POST["TRANGTHAI_2210900032"];
        if($_POST["ANH"]!=""){
            $ANH_2210900032 = $_POST["ANH"];
        }
        $sql_update_vdk = "UPDATE bang_vuduckhoa SET TEN_2210900032='$TEN_2210900032' ";
        $sql_update_vdk .= " ,SL_2210900032=$SL_2210900032";
        $sql_update_vdk .= " ,DG_2210900032=$DG_2210900032";
        $sql_update_vdk .= " ,ANH_2210900032='$ANH_2210900032'";
        $sql_update_vdk .= " ,TRANGTHAI_2210900032=$TRANGTHAI_2210900032";
        $sql_update_vdk .= " WHERE MA_2210900032= '$MA_2210900032'";
        //die($sql_update_vdk);
        if($conn_vdk->query($sql_update_vdk)){
            header("location:sanpham-list-vuduckhoa.php");
        }else{
            $error_vdk="lỗi cập nhập, ". $conn_vdk->error. "<p> $sql_update_vdk ";
        }
    }
    if(isset($_GET["id"])){
        $sql_edit_vdk = "SELECT * FROM bang_vuduckhoa WHERE MA_2210900032 ='" . $_GET["id"] . "'";
        $result_vdk = $conn_vdk->query($sql_edit_vdk);
        $row_vdk = $result_vdk->fetch_array();
    }
    ?>
    

    <header>
        <h1> sửa sản phẩm ... Vũ Đức Khoa 2210900032</h1>
    </header>
    <form action="" method="post">
        <div>
            <label> Mã </label>
            <input type="text" name="MA_2210900032" value="<?php echo $row_vdk["MA_2210900032"];?>">
        </div>
        <div>
            <label> Tên </label>
            <input type="text" name="TEN_2210900032"value="<?php echo $row_vdk["TEN_2210900032"];?>">
        </div>
        <div>
            <label> Sl </label>
            <input type="text" name="SL_2210900032"value="<?php echo $row_vdk["SL_2210900032"];?>">
        </div>
        <div>
            <label> đơn giá </label>
            <input type="text" name="DG_2210900032"value="<?php echo $row_vdk["DG_2210900032"];?>">
        </div>
        <div>
            <label> ảnh </label>
            <input type="hidden" name="ANH_2210900032" value="<?php echo $row_vdk["ANH_2210900032"];?>">
            <input type="file" name="ANH">
        </div>
        <div>
            <label> Trạng thái </label>
            <input type="radio" value="1" name="TRANGTHAI_2210900032" id="TT1"
                <?php echo $row_vdk["TRANGTHAI_2210900032"]==1?"checked":""
                ?>
            > 
            <label for="TT1"> Hiện</label>
            <input type="radio" value="0" name="TRANGTHAI_2210900032" id="TT2"
                <?php echo $row_vdk["TRANGTHAI_2210900032"]==0?"checked":""
                ?>
            >
            <label for="TT2"> Ẩn</label>
        </div>
        <input type="submit" value="thêm" name="btn_vdk">
        <div>
            <?php
            if(isset($error_vdk)){
                echo $error_vdk;
            }
            ?>
        </div>
    </form>
</body>
</html>