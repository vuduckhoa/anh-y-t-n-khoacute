<?php
    $conn_vdk = new mysqli("localhost","root","","qlbh_vuduckhoacntt3");
?>