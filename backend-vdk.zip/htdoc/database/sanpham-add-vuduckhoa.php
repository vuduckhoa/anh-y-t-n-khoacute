<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>thêm... Vũ Đức Khoa 2210900032</title>
</head>
<body>
    <?php
        $error_vdk = "";
        if(isset($_POST["btn_vdk"])){
        include("ketnoi-vuduckhoa.php");
        $MA_2210900032 = $_POST["MA_2210900032"];
        $TEN_2210900032 = $_POST["TEN_2210900032"];
        $SL_2210900032 = $_POST["SL_2210900032"];
        $DG_2210900032 = $_POST["DG_2210900032"];
        $ANH_2210900032 = $_POST["ANH_2210900032"];
        $TRANGTHAI_2210900032 = $_POST["TRANGTHAI_2210900032"];
        $sql_vdk = "INSERT INTO bang_vuduckhoa(MA_2210900032,TEN_2210900032,SL_2210900032,DG_2210900032,ANH_2210900032,TRANGTHAI_2210900032) ";
        $sql_vdk .= " VALUES('$MA_2210900032','$TEN_2210900032',$SL_2210900032,$DG_2210900032,'$ANH_2210900032','$TRANGTHAI_2210900032')";
        //echo $sql_vdk;
        //die;
        if($conn_vdk->query($sql_vdk)){
            header("location:sanpham-list-vuduckhoa.php");
        }else{
            $error = "lỗi thêm mới; ". $conn_vdk->error;
        }
        }
    ?>
    <header>
        <h1> thêm sản phẩm ... Vũ Đức Khoa 2210900032</h1>
    </header>
    <form action="" method="post">
        <div>
            <label> Mã </label>
            <input type="text" name="MA_2210900032">
        </div>
        <div>
            <label> Tên </label>
            <input type="text" name="TEN_2210900032">
        </div>
        <div>
            <label> Sl </label>
            <input type="text" name="SL_2210900032">
        </div>
        <div>
            <label> đơn giá </label>
            <input type="text" name="DG_2210900032">
        </div>
        <div>
            <label> ảnh </label>
            <input type="file" name="ANH_2210900032">
        </div>
        <div>
            <label> Trạng thái </label>
            <input type="radio" value="1" name="TRANGTHAI_2210900032" id="TT1"> <label for="TT1"> Hiện</label>
            <input type="radio" value="0" name="TRANGTHAI_2210900032" id="TT2"> <label for="TT2"> Ẩn</label>
        </div>
        <input type="submit" value="thêm" name="btn_vdk">
        <div>
            <?php
            if(isset($error_vdk)){
                echo $error_vdk;
            }
            ?>
        </div>
    </form>
</body>
</html>