<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
        include("ketnoi-vuduckhoa.php");
        $sql_pb_vdk = "SELECT * FROM sanpham_vdk  WHERE 1=1";
        $res_pb_vdk = $conn_vdk->query($sql_pb_vdk);
        if(isset($_POST["btnSubmit_vdk"])){
            $SPID_VDK = $_POST["SPID_VDK"];
            $TESP_VDK = $_POST["TESP_VDK"];
            $SOLUONG_VDK = $_POST["SOLUONG_VDK"];
            $GIAMUA_VDK = $_POST["GIAMUA_VDK"];
            $GIABAN_VDK = $_POST["GIABAN_VDK"];
            $TRANGTHAI_VDK = $_POST["TRANGTHAI_VDK"];
            $MADM_VDK = $_POST["MADM_VDK"];
            $sql_check_vdk = "SELECT SPID_VDK FROM sanpham_vdk WHERE SPID_VDK = 'SPID_VDK' ";
            $res_check_vdk = $conn_vdk->query($sql_check_vdk);
            if($res_check_vdk->num_rows>0){
                $error_message_vdk="Lỗi trùng khóa chính.";
            }
            $sql_insert_vdk = "INSERT INTO sanpham_vdk ('SPID_VDK', 'TESP_VDK', 'SOLUONG_VDK','GIAMUA_VDK', 'GIABAN_VDK', 'TRANGTHAI_VDK', 'MADM_VDK')";
            $sql_insert_vdk.="VALUES ('$SPID_VDK','$TESP_VDK','$SOLUONG_VDK','$GIAMUA_VDK','$GIABAN_VDK','$TRANGTHAI_VDK','$MADM_VDK');";
            if($conn_vdk->query($sql_insert_vdk)){
                header("Location: sanpham-lisT-vdk.php"); 
            }else{
                $error_message_vdk="Lỗi thêm mới". mysqli_error($conn_vdk);
            }
        }
        ?>
    <section class="container">
        <h1>Thêm mới thông tin sản phẩm</h1>
        <form name="frm_vdk" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã</td>
                        <td>
                            <input type="text" name="SPID_VDK" id="SPID_VDK">
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TESP_VDK" id="TESP_VDK">
                        </td>
                    </tr>
                    <tr>
                        <td>Giá mua</td>
                        <td>
                            <input type="text" name="GIAMUA_VDK" id="GIAMUA_VDK">
                        </td>
                    </tr>
                    <tr>
                        <td>Giá bán</td>
                        <td>
                            <input type="text" name="GIABAN_VDK" id="GIABAN_VDK">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_VDK" >
                                <option value="1" selected>Hoạt động</option>
                                <option value="0" selected>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Mã danh mục</td>
                        <td>
                        <input type="text" name="MADM_VDK" id="MADM_VDK">
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="reset" value="Làm lại" name="btnReset_vdk">
                        </td>
                    </tr>
                </tbody>
            </table>    
        </form>
        <a href="sanpham-list-vdk.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>